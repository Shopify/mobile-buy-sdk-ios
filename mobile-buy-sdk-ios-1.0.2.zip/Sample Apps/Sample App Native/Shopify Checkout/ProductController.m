//
//  ProductViewController.m
//  Checkout
//
//  Created by Shopify.
//  Copyright (c) 2015 Shopify. All rights reserved.
//

@import PassKit;
@import AddressBook;
#import <Buy/Buy.h>

#import "ProductController.h"
#import "ProductView.h"

@implementation ProductController {
	ProductView *_view;
	BUYProductVariant *_product;
	
	NSString *_initialProductId;
}

- (instancetype)initWithDataProvider:(BUYClient *)dataProvider productId:(NSString *)productId;
{
	self = [super initWithDataProvider:dataProvider];
	if (self) {
		_initialProductId = productId;
	}
	return self;
}

- (void)loadView
{
	_view = [[ProductView alloc] init];
	self.view = _view;
	
	[_view.paymentButton addTarget:self action:@selector(applePayPressed:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	[_view showLoading:YES];
	
	//Download the necessary product information from Shopify, given a handle and (optionally) a variant id.
    [self.provider getProductById:_initialProductId completion:^(BUYProduct *product, NSError *error) {
        
    	//NOTE: You would want to display your product + a picker to select the correct variant or iterate the variants and pick the right one
		_product = [product.variants firstObject];
		
		UIImage *image = nil;
		if ([[product images] count] > 0) {
			BUYImage *productImage = [[product images] firstObject];
			image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:productImage.src]]];
		}
		
		dispatch_async(dispatch_get_main_queue(), ^{
			[_view showLoading:NO];
			_view.productImageView.image = image;
			_view.titleLabel.text = product.title;
			 //NOTE: You will want to format this correctly, based on the user locale + currency of your shop.
			_view.priceLabel.text = _product ? [NSString stringWithFormat:@"$%@", [_product.price stringValue]] : @"No product";
			_view.paymentButton.enabled = _product != nil;
		});
	}];
}

- (void)applePayPressed:(id)sender
{
	// Step 1 - Create the checkout on Shopify. This demo only works with ApplePay.
	if ([PKPaymentAuthorizationViewController canMakePayments]) {
		BUYCart *cart = [[BUYCart alloc] init];
		[cart addVariant:_product];
		
		// This starts the main process, detailed in BUYViewController. You can copy the functionality/subclass BUYViewController to add Apple Pay functionality to your app.
		// You will likely want to tweak the BUYViewController so that you handle errors correctly, as you want them to be presented in your app.
		// The default behaviour in the BUYViewController is to NSLog the error, which the user will never see.
		[self startCheckoutWithCart:cart];
	}
    else {
        // Alternativelty, a web view with the checkout flow could be displayed, or a fully native checkout which then calls `completeCheckout:completion`
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Apple Pay not supported on this device" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertView show];
    }
}

@end
