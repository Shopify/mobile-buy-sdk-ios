//
//  main.m
//  Shopify Checkout
//
//  Created by Rune Madsen on 2015-04-29.
//  Copyright (c) 2015 Shopify. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
